package com.ntmi.support;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NtmiSupportBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
